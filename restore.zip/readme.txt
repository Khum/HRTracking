For installation instructions, please read doc/INSTALL.
